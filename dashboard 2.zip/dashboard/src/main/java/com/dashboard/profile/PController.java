package com.dashboard.profile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@RestController
@Controller
@RequestMapping("/api")
@CrossOrigin
public class PController {

	
	@Autowired
	private PService ps;
	@GetMapping("/get/follower/{id}")
	public ResponseEntity getAllFollowers(@PathVariable Long id){
		return  new ResponseEntity(
				ps.getAllFollowers(id),
				(HttpStatus.OK)
				);
	}
	@GetMapping("/get/following/{id}")
	public ResponseEntity getAllFollowing(@PathVariable Long id){
		return  new ResponseEntity(
				ps.getAllFollowing(id),
				(HttpStatus.OK)
				);
	}

	
}

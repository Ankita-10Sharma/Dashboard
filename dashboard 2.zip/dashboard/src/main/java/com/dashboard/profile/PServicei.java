package com.dashboard.profile;

import java.util.List;

import com.dashboard.model.Follower;
import com.dashboard.model.Followers;

public interface PServicei  {

	public Long getAllFollowers(Long id);
	public Long getAllFollowing(Long id);
}

package com.dashboard.profile;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dashboard.model.Follower;


@Repository
public interface Prepo extends JpaRepository<Follower,Integer>{

	@Query(value="select COUNT(follow_id) from Follower where u_id = :uid",nativeQuery=true)
	public Long countt(@Param("uid")Long uid);
	
	@Query(value="select COUNT(u_id) from Follower where follow_id = :fid",nativeQuery=true)
	public Long countFollowing(@Param("fid")Long fid);
	
}

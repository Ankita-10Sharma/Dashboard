package com.dashboard.profile;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.dashboard.model.Follower;
import com.dashboard.model.Followers;

@Service
public class PService  implements PServicei{
	@Autowired
     private Prepo pr;

	@Override
	public Long getAllFollowers(Long id) {
		return pr.countt(id);
		
	}

	@Override
	public Long getAllFollowing(Long id) {
		return pr.countFollowing(id);
	}
	

	

}

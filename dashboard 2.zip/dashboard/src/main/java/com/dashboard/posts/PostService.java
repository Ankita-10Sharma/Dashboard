package com.dashboard.posts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PostService implements PService {

	@Autowired 
	private PostR pr;
	@Override
	public Long getNoP(Long uid) {
		return pr.noP(uid);
	}

}

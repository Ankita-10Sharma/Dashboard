package com.dashboard.posts;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dashboard.model.Posts;

@Repository
public interface PostR extends JpaRepository<Posts,Integer> {

	@Query(value="select Count(u_id)from posts where u_id =:uid",nativeQuery=true)
	public Long noP(@Param("uid")Long uid);
	
	
	
}

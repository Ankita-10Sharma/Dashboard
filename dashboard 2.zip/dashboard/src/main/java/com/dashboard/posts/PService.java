package com.dashboard.posts;

public interface PService {

	public Long getNoP(Long uid);
}

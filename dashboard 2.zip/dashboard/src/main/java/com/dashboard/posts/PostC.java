package com.dashboard.posts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dashboard.profile.PService;

@Controller
@RequestMapping("/api")
@CrossOrigin
public class PostC {
	
	@Autowired
	private PostService ps;
	
	@GetMapping("/get/post/{id}")
	public ResponseEntity getNo(@PathVariable Long id){
		return  new ResponseEntity(
				ps.getNoP(id),
				(HttpStatus.OK)
				);
	}

}

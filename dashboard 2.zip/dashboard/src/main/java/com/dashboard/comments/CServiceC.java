package com.dashboard.comments;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CServiceC implements CService {

	@Autowired
	private CommentR cr;
	@Override
	public Long allC(Long uid) {
		return cr.noC(uid);
	}

}

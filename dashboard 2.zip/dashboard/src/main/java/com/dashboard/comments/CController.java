package com.dashboard.comments;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dashboard.UserD.UserService;

@Controller
@RequestMapping("/api")
@CrossOrigin
public class CController {

	@Autowired
	private CServiceC sc;
	
	@GetMapping("/get/comments/{id}")
	public ResponseEntity getC(@PathVariable Long id){
		return  new ResponseEntity(
				sc.allC(id),
				(HttpStatus.OK)
				);
	}
}

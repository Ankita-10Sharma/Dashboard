package com.dashboard.comments;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dashboard.model.Comments;
import com.dashboard.model.Userdetails;

@Repository
public interface CommentR extends JpaRepository<Comments,Integer> {

	@Query(value="select count(u_id) from comments where u_id =:ui",nativeQuery=true)
	public Long noC(@Param("ui")Long uid);
}

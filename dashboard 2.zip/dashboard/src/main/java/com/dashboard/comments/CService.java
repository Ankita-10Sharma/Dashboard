package com.dashboard.comments;

public interface CService {
public Long allC(Long uid);
}

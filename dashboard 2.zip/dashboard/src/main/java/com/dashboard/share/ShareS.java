package com.dashboard.share;

public interface ShareS {

	public Long ts(Long id);
}

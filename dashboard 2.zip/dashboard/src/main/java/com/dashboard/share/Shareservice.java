package com.dashboard.share;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Shareservice implements ShareS {

	@Autowired
	private ShareR sr;
	@Override
	public Long ts(Long id) {
		// TODO Auto-generated method stub
		return sr.noSave(id);
	}

}

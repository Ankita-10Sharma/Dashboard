package com.dashboard.share;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dashboard.model.Share;

@Repository
public interface ShareR extends JpaRepository<Share,Integer> {
	@Query(value="select count(u_id) from share where u_id =:ui",nativeQuery=true)
	public Long noSave(@Param("ui")Long uid);
}

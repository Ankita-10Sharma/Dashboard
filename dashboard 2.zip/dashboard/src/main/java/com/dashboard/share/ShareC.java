package com.dashboard.share;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dashboard.Save.SaveService;

@Controller
@RequestMapping("/api")
@CrossOrigin
public class ShareC {
	@Autowired
	private Shareservice ss;
	
	@GetMapping("/get/share/{id}")
	public ResponseEntity getS(@PathVariable Long id){
		return  new ResponseEntity(
				ss.ts(id),
				(HttpStatus.OK)
				);
	}

}

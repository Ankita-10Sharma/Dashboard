package com.dashboard.Save;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dashboard.model.Likes;
import com.dashboard.model.Userdetails;

@Repository
public interface SaveR extends JpaRepository<Likes,Integer> {

	@Query(value="select count(u_id) from likes where u_id =:ui",nativeQuery=true)
	public Long noSave(@Param("ui")Long uid);
}

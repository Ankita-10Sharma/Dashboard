package com.dashboard.Save;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SaveService implements SaveSI {

	@Autowired 
	private SaveR sr;
	@Override
	public Long noSave(Long id) {
		return sr.noSave(id);
	}

}

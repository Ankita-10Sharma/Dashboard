package com.dashboard.Save;

public interface SaveSI {

	public Long noSave(Long id);
}

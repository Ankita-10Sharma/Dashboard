package com.dashboard.insta;

import java.util.List;

import com.dashboard.model.Insatu;

public interface IServicei {
public List<Insatu> getAllI();
}

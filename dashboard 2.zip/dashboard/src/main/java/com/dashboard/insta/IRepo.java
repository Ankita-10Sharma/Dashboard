package com.dashboard.insta;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.dashboard.model.Insatu;
import com.dashboard.model.Userdetails;

public interface IRepo extends JpaRepository<Insatu,Integer>  {
	@Query(value="select * from insatu ",nativeQuery=true)
	public List<Insatu> no();
	
}

package com.dashboard.insta;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dashboard.profile.PService;


	@Controller
	@RequestMapping("/api")
	@CrossOrigin
	public class IController {

		
		@Autowired
		private Iservice is;
		@GetMapping("/get/u/all")
		public ResponseEntity getAllI(){
			return  new ResponseEntity(
					is.getAllI(),
					(HttpStatus.OK)
					);
		}
}

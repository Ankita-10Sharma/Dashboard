package com.dashboard.insta;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dashboard.model.Insatu;
@Service
public class Iservice implements IServicei {

	@Autowired
	private IRepo ir;
	
	@Override
	public List<Insatu> getAllI() {
		// TODO Auto-generated method stub
		return ir.no();
	}

}

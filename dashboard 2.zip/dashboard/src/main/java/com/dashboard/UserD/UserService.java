package com.dashboard.UserD;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dashboard.model.Userdetails;

@Service
public class UserService implements UServiceI {

	@Autowired
	private UserR ue;
	@Override
	public List<Userdetails> getD(Long uid) {
		return ue.noC(uid);
	}

}

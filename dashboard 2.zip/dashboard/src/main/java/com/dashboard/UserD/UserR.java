package com.dashboard.UserD;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dashboard.model.Userdetails;

@Repository
public interface UserR extends JpaRepository<Userdetails,Integer>{

	@Query(value="select * from userdetails where u_id =:ui",nativeQuery=true)
	public List<Userdetails> noC(@Param("ui")Long uid);
	

	
}

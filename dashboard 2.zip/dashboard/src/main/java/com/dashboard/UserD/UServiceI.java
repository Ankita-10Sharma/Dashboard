package com.dashboard.UserD;

import java.util.List;

import com.dashboard.model.Userdetails;

public interface UServiceI {

	public List<Userdetails> getD(Long uid);
}

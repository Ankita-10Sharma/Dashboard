package com.dashboard.model;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Share {
	@SuppressWarnings("deprecation")
	@Id
	@Column(name="s_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@GenericGenerator(strategy="native",name="native")
	private Long sid;
	@ManyToOne
	@JoinColumn(name="u_id")
	private Userdetails uid;
	public Long getSid() {
		return sid;
	}
	public void setSid(Long sid) {
		this.sid = sid;
	}
	public Userdetails getUid() {
		return uid;
	}
	public void setUid(Userdetails uid) {
		this.uid = uid;
	}
	public Share(Long sid, Userdetails uid) {
		super();
		this.sid = sid;
		this.uid = uid;
	}
	@Override
	public String toString() {
		return "Share [sid=" + sid + ", uid=" + uid + "]";
	}
	public Share() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

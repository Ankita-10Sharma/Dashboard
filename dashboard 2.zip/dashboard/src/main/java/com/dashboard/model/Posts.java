package com.dashboard.model;

import java.util.Date;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Posts {
	@SuppressWarnings("deprecation")
	@Id
	@Column(name="p_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@GenericGenerator(strategy="native",name="native")
	private Long pid;
	@Column(name="pic")
	private String picurl;
	@Column(name="descp")
	private String des;
	@Column(name="dop")
	private Date dop;
	@ManyToOne
	@JoinColumn(name="u_id")
	private Userdetails user1;
	public Long getPid() {
		return pid;
	}
	public void setPid(Long pid) {
		this.pid = pid;
	}
	public String getPicurl() {
		return picurl;
	}
	public void setPicurl(String picurl) {
		this.picurl = picurl;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	public Date getDop() {
		return dop;
	}
	public void setDop(Date dop) {
		this.dop = dop;
	}
	public Userdetails getUser1() {
		return user1;
	}
	public void setUser1(Userdetails user1) {
		this.user1 = user1;
	}
	@Override
	public String toString() {
		return "Posts [pid=" + pid + ", picurl=" + picurl + ", des=" + des + ", dop=" + dop + ", user1=" + user1 + "]";
	}
	public Posts(Long pid, String picurl, String des, Date dop, Userdetails user1) {
		super();
		this.pid = pid;
		this.picurl = picurl;
		this.des = des;
		this.dop = dop;
		this.user1 = user1;
	}
	public Posts() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

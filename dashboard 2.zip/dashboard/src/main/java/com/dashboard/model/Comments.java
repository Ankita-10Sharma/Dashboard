package com.dashboard.model;

import java.util.Date;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Comments {
	@SuppressWarnings("deprecation")
	@Id
	@Column(name="c_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@GenericGenerator(strategy="native",name="native")
	private Long cid;
	@Column(name="descp",columnDefinition="VARCHAR(50)")
	private String comments;
	@Column(name="dop",columnDefinition="VARCHAR(50)")
	private Date d;
	@ManyToOne
	@JoinColumn(name="u_id")
	private Userdetails user;
	@ManyToOne
	@JoinColumn(name="p_id")
	private Posts post;
	public Comments() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Comments(Long cid, String comments, Date d, Userdetails user, Posts post) {
		super();
		this.cid = cid;
		this.comments = comments;
		this.d = d;
		this.user = user;
		this.post = post;
	}
	@Override
	public String toString() {
		return "Comments [cid=" + cid + ", comments=" + comments + ", d=" + d + ", user=" + user + ", post=" + post
				+ "]";
	}
	public Long getCid() {
		return cid;
	}
	public void setCid(Long cid) {
		this.cid = cid;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Date getD() {
		return d;
	}
	public void setD(Date d) {
		this.d = d;
	}
	public Userdetails getUser() {
		return user;
	}
	public void setUser(Userdetails user) {
		this.user = user;
	}
	public Posts getPost() {
		return post;
	}
	public void setPost(Posts post) {
		this.post = post;
	}
	
}

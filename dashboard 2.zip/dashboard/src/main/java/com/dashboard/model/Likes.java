package com.dashboard.model;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Likes {
	@SuppressWarnings("deprecation")
	@Id
	@Column(name="l_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@GenericGenerator(strategy="native",name="native")
	private Long lid;
	@ManyToOne
	@JoinColumn(name="u_id")
	private Userdetails uid;
	public Long getLid() {
		return lid;
	}
	public void setLid(Long lid) {
		this.lid = lid;
	}
	public Userdetails getUid() {
		return uid;
	}
	public void setUid(Userdetails uid) {
		this.uid = uid;
	}
	@Override
	public String toString() {
		return "Likes [lid=" + lid + ", uid=" + uid + "]";
	}
	public Likes(Long lid, Userdetails uid) {
		super();
		this.lid = lid;
		this.uid = uid;
	}
	public Likes() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

package com.dashboard.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Followers {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int posts;
	private int Followers;
	private int following;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPosts() {
		return posts;
	}
	public void setPosts(int posts) {
		this.posts = posts;
	}
	public int getFollowers() {
		return Followers;
	}
	public void setFollowers(int followers) {
		Followers = followers;
	}
	public int getFollowing() {
		return following;
	}
	public void setFollowing(int following) {
		this.following = following;
	}
	@Override
	public String toString() {
		return "Followers [id=" + id + ", posts=" + posts + ", Followers=" + Followers + ", following=" + following
				+ "]";
	}
	public Followers(int id, int posts, int followers, int following) {
		super();
		this.id = id;
		this.posts = posts;
		Followers = followers;
		this.following = following;
	}
	public Followers() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}

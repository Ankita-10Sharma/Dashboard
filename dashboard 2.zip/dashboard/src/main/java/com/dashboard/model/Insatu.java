package com.dashboard.model;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Insatu {
	@SuppressWarnings("deprecation")
	@Id
	@Column(name="u_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@GenericGenerator(strategy="native",name="native")
	private Long uid;
	@Column(name="uname",columnDefinition="VARCHAR(50)")
	private String namee;
	@Column(name="upass",columnDefinition="VARCHAR(50)")
	private String pass;
	public Insatu() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Insatu(Long uid, String namee, String pass) {
		super();
		this.uid = uid;
		this.namee = namee;
		this.pass = pass;
	}
	public Insatu(String pass) {
		super();
		this.pass = pass;
	}
	@Override
	public String toString() {
		return "Insatu [uid=" + uid + ", namee=" + namee + ", pass=" + pass + "]";
	}
	public Long getUid() {
		return uid;
	}
	public void setUid(Long uid) {
		this.uid = uid;
	}
	public String getNamee() {
		return namee;
	}
	public void setNamee(String namee) {
		this.namee = namee;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
}

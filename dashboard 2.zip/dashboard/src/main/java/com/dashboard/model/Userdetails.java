package com.dashboard.model;

import java.util.Date;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Userdetails {

	@SuppressWarnings("deprecation")
	@Id
	@Column(name="u_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@GenericGenerator(strategy="native",name="native")
	private Long uid;
	@Column(name="f_n",columnDefinition="VARCHAR(50)")
	private String firstname;
	@Column(name="l_n",columnDefinition="VARCHAR(50)")
	private String lastname;
	@Column(name="p_n",columnDefinition="VARCHAR(50)")
	private String phoneno;
	@Column(name="email",columnDefinition="VARCHAR(200)")
	private String mail;
	@Column(name="pic",columnDefinition="VARCHAR(50)")
	private String profileimg;
	@Column(name="dob")
	private Date date;
	@Column(name="bio",columnDefinition="VARCHAR(4000)")
	private String bio;
	@Column(name="isprivate",length=1)
	private int isprivate=0;
	public Long getUid() {
		return uid;
	}
	public void setUid(Long uid) {
		this.uid = uid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getProfileimg() {
		return profileimg;
	}
	public void setProfileimg(String profileimg) {
		this.profileimg = profileimg;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getBio() {
		return bio;
	}
	public void setBio(String bio) {
		this.bio = bio;
	}
	public int getIsprivate() {
		return isprivate;
	}
	public void setIsprivate(int isprivate) {
		this.isprivate = isprivate;
	}
	@Override
	public String toString() {
		return "Userdetails [uid=" + uid + ", firstname=" + firstname + ", lastname=" + lastname + ", phoneno="
				+ phoneno + ", mail=" + mail + ", profileimg=" + profileimg + ", date=" + date + ", bio=" + bio
				+ ", isprivate=" + isprivate + "]";
	}
	public Userdetails(Long uid, String firstname, String lastname, String phoneno, String mail, String profileimg,
			Date date, String bio, int isprivate) {
		super();
		this.uid = uid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.phoneno = phoneno;
		this.mail = mail;
		this.profileimg = profileimg;
		this.date = date;
		this.bio = bio;
		this.isprivate = isprivate;
	}
	public Userdetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

package com.dashboard.model;

import java.util.Date;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Follower {

	@SuppressWarnings("deprecation")
	@Id
	@Column(name="f_id")
	@GeneratedValue(strategy=GenerationType.AUTO,generator="native")
	@GenericGenerator(strategy="native",name="native")
	private Long fid;
	@Column(name="createddate",nullable=false)
	private Date cd;
	@Column(name="updateddate",nullable=false)
	private Date ud;
	@ManyToOne
	@JoinColumn(name="u_id")
	private Userdetails user;
	@ManyToOne
	@JoinColumn(name="follow_id")
	private Userdetails followers;
	public Long getFid() {
		return fid;
	}
	public void setFid(Long fid) {
		this.fid = fid;
	}
	public Date getCd() {
		return cd;
	}
	public void setCd(Date cd) {
		this.cd = cd;
	}
	public Date getUd() {
		return ud;
	}
	public void setUd(Date ud) {
		this.ud = ud;
	}
	public Userdetails getUser() {
		return user;
	}
	public void setUser(Userdetails user) {
		this.user = user;
	}
	public Userdetails getFollowers() {
		return followers;
	}
	public void setFollowers(Userdetails followers) {
		this.followers = followers;
	}
	@Override
	public String toString() {
		return "Follower [fid=" + fid + ", cd=" + cd + ", ud=" + ud + ", user=" + user + ", followers=" + followers
				+ "]";
	}
	public Follower(Long fid, Date cd, Date ud, Userdetails user, Userdetails followers) {
		super();
		this.fid = fid;
		this.cd = cd;
		this.ud = ud;
		this.user = user;
		this.followers = followers;
	}
	public Follower() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

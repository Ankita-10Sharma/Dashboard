import React from 'react'
import  { useEffect, useState } from "react";
import { RiFolderSharedLine } from "react-icons/ri";
import { FaComment } from "react-icons/fa";
import { DiHtml5Multimedia } from "react-icons/di";
import "./Following.css";
function Share() {
    const url3=`http://localhost:8080/api/get/share/1`;
    const url=`http://localhost:8080/api/get/comments/1`;
    const urla=`http://localhost:8080/api/get/save/1`;
    const [postt, setPostt] = useState([]);
    const [post, setPost] = useState([]);
    const [pos, setPos] = useState([]);
    const fetchApiDatas = async (url3) => {
      try {
        const res = await fetch(url3);
        const data = await res.json();
        setPostt(data);
        console.log(data);
      } catch (error) {
        console.log(error);
      }
    };
    const fetchApiData = async (url) => {
        try {
          const res = await fetch(url);
          const data = await res.json();
          setPost(data);
          console.log(data);
        } catch (error) {
          console.log(error);
        }
      };
      const fetchApiDataa = async (urla) => {
        try {
          const res = await fetch(urla);
          const data = await res.json();
          setPos(data);
          console.log(data);
        } catch (error) {
          console.log(error);
        }
      };
    useEffect(() => {
      fetchApiDatas(url3);
      fetchApiData(url);
      fetchApiDataa(urla);
    }, []);
  return (
    <>
    <div className=" proo text-5xl ">
        <div>
    <h2 className='flex items-center mb-5 cursor-pointer '> <RiFolderSharedLine  className='mr-3'/>Total Shared Posts : {postt}</h2><br/>
    <h2 className='flex items-center mb-5 cursor-pointer '>  <FaComment  className='mr-3'/>Total Comments : {postt}</h2><br/>
    <h2 className='flex items-center mb-5 cursor-pointer '><DiHtml5Multimedia className='mr-3'/>Saved Posts : {pos}</h2>
    </div>
    </div>
    </>
  )
}

export default Share
import React from 'react'
import  { useEffect, useState } from "react";
import "./Following.css";
import { CgProfile } from "react-icons/cg";
import { MdOutlineMailOutline } from "react-icons/md";
import { FaPhoneAlt } from "react-icons/fa";
import { CiCalendarDate } from "react-icons/ci";
export default  function Userd() {
    const url3=`http://localhost:8080/api/get/details/1`;
    const [postt, setPostt] = useState([]);
    const [loading, setLoading] = useState(true)
    const fetchApiDatas = async (url3) => {
      try {
        const res = await fetch(url3);
        const data = await res.json();
        setPostt(data[0]);
        console.log(data[0]);
      } catch (error) {
        console.log(error);
      }
    };
    useEffect(() => {
      fetchApiDatas(url3);
    }, []);

    
  return (
    <>
  
<div className='container px-10 text-4xl  '>
        <h2 className='px-8 text-4xl flex  mx-4' htmlfor="name"><CgProfile className='mr-3'/>First Name : <input className=' text-4xl px-1' type="text" id="name" name="name" value={postt.firstname}/></h2><br/>

        <h2 className='px-8 text-4xl flex mx-4'for="name"><CgProfile className='mr-3'/>Last Name : <input className='px-1 text-4xl ' type="text" id="name" name="name" value={postt.lastname}/></h2><br/>
       
        <h2 className='px-8 text-4xl flex mx-4'for="email"><MdOutlineMailOutline className='mr-3'/>Email : <input className='px-1 text-4xl ' type="email" id="email" name="email" value={postt.mail}/><br/></h2><br/>

        <h2 className='px-8 text-4xl flex mx-4' for="phone"><FaPhoneAlt className='mr-3'/>Phone Number : <input className='px-1 text-4xl ' type="tel" id="phone" name="phone" pattern="[0-9]{10}" value={postt.phoneno}/></h2><br/>
        
        <h2 className='px-8 text-4xl flex mx-4' for="phone"><CiCalendarDate className='mr-3'/>Date Of Creation :  <input className='px-1 text-4xl' type="tel" id="phone" name="phone" pattern="[0-9]{10}" value={postt.date}/></h2><br/>
       
    </div>

    </>
  )
}


import React, { useState } from 'react'
import  './Following.css';
import { IoReorderThree } from "react-icons/io5";
import { menu } from './Side';
import { useNavigate } from 'react-router-dom';
function Slidebar() {
    const [active,setActive]=useState()
    const navigate=useNavigate()
   const handle=(t)=>{
    setActive(t);
    if(t==="Profile"){
        navigate("/profile/:uid")
    }
    }
  return (
  <>
  <div className='sticky top-0 h-[100vh] '>
    <div className='flex flex-col justify-between h-full px-10'>
        <div>
        <div className='pt-10'>
        <div className="logo">
                <h1>Social Media</h1>
    </div>
    </div>
    <div  className='mt-10 '>
        {menu.map((item)=>
            <div onClick={()=>handle(item.title)} className='flex items-center mb-5 cursor-pointer text-lg'>
                {active===item.title?item.iactiveIcon: item.icon}
            <p className={`${active=== item.title?"text-black font-bold":"font-semibold"}`} id="m" >{item.title}</p>
            
                </div>
        )}
    </div>
    </div>
    <div className='flex items-center pb-10'>
  <IoReorderThree className=' text-6xl' />
  <p className='p ml-5 '>More</p>
  </div>
        </div>
    </div>
  
  </>
  )
}

export default Slidebar
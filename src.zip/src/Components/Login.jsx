import React, { useState } from 'react'
import  './Login.css';
import { useNavigate } from "react-router-dom";
import Profile from './Profile';

export default function Login() {
    const[user,setuser]=useState([])
    const [uid, setUid] = useState(null);
    let [namee,setName]=useState('');
    let [pass,setPass]=useState('');
   
    const navigate = useNavigate()
  
  
    const handleSubmit=async (e)=>{
      e.preventDefault();
      const data=await fetch("http://localhost:8080/api/get/u/all")
      const res=await data.json();
      console.log(res)

   
      if(namee==res[0].namee && pass==res[0].pass ){
        console.log(pass);
        // const uid=res[0].uid
        const fetchedUid = res[0].uid;
        <Profile uid={uid} />
        console.log(res[0].uid)
        setUid(fetchedUid);
        
         navigate(`/profile/${fetchedUid}`)  
      }
    }

  return (
    <>
    <div>
    <div id="wrapper">
        <div className="container">
          <div className="phone-app-demo" />
          <div className="form-data">
            <form action="">
              <div className="logo">
                <h1>Social Media</h1>
              </div>
              <input
                type="text"
                placeholder="Phone number, username, or email"
                value={namee}
                onChange={(e) => setName(e.target.value)}
              />
              <input type="text" placeholder="Password" value={pass}  onChange={(e) => setPass(e.target.value)}/>
              <button className="form-btn" type="submit" onClick={handleSubmit} >
                Log in
              </button>
              <span className="has-separator">Or</span>
              <a href="#" className="facebook-login">
                <i className="fab fa-facebook" /> Log in with Facebook
              </a>
              <a className="password-reset" href="#">
                Forgot password?
              </a>
            </form>
            <div className="get-the-app">
              <span>Get the app</span>
              <div className="badge">
                <img
                  src="https://www.instagram.com/static/images/appstore-install-badges/badge_android_english-en.png/e9cd846dc748.png"
                  alt="android App"
                />
                <img
                  src="https://www.instagram.com/static/images/appstore-install-badges/badge_ios_english-en.png/180ae7a0bcf7.png"
                  alt="ios app"
                />
              </div>
            </div>
          </div>
        </div>

        <footer>
          <div className="container">
            <div className="copyright-notice">&copy; 2024 Copyright</div>
          </div>
        </footer>
      </div>
      
    </div>
 
    </>
  )
}



import { AiFillCompass, AiFillHeart, AiFillMessage, AiFillPlusCircle, AiOutlineCompass, AiOutlineHeart, AiOutlineHome, AiOutlineMessage, AiOutlinePlusCircle, AiOutlineSearch } from "react-icons/ai";
import { RiVideoAddLine, RiVideoFill } from "react-icons/ri";
import { CgProfile } from "react-icons/cg";
export const menu=[
    {title :"Home",icon:<AiOutlineHome className="text-5xl mr-5"/>,iactiveIcon:<AiOutlineHome className="text-5xl mr-5"/>},
    {title:"Search",icon:<AiOutlineSearch className="text-5xl mr-5"/>,iactiveIcon:<AiOutlineSearch className="text-5xl mr-5" />},
    {title:"Explore",icon:<AiOutlineCompass className="text-5xl mr-5"/>,iactiveIcon:<AiFillCompass className="text-5xl mr-5" />},
    {title:"Reels",icon:<RiVideoAddLine className="text-5xl mr-5"/>, iactiveIcon:<RiVideoFill className="text-5xl mr-5"/>},
    {title:"Message",icon:<AiOutlineMessage className="text-5xl mr-5" />, iactiveIcon:<AiFillMessage className="text-5xl mr-5"/>},
    {title:"Notification",icon:<AiOutlineHeart className="text-5xl mr-5"/>, iactiveIcon:<AiFillHeart className="text-5xl mr-5"/>},
    {title:"create",icon:<AiOutlinePlusCircle className="text-5xl mr-5"/>, iactiveIcon:<AiFillPlusCircle className="text-5xl mr-5"/>},
    {title:"Profile",icon:<CgProfile className="text-5xl mr-5"/>, iactiveIcon:<CgProfile className="text-5xl mr-5"/>}
]
import React from 'react'
import  { useEffect, useState } from "react";
import "./Following.css";
import { RiChatPrivateFill } from "react-icons/ri";
import { MdOutlineDescription } from "react-icons/md";
export default function Userinfo() {
    const url3=`http://localhost:8080/api/get/details/1`;
    const [postt, setPostt] = useState([]);
    const fetchApiDatas = async (url3) => {
      try {
        const res = await fetch(url3);
        const data = await res.json();
        setPostt(data[0]);
        console.log(data[0]);
      } catch (error) {
        console.log(error);
      }
    };
    useEffect(() => {
      fetchApiDatas(url3);
    }, []);
  return (
   <>
   <div className="proo text-5xl ">
      <div >
        <h2 className='flex items-center  mb-5 cursor-pointer '><RiChatPrivateFill className='mr-3'/>Account Type :{postt.isprivate?"Private":"Public"}</h2><br/>
        <p className='flex items-center mb-5 cursor-pointer'><MdOutlineDescription className='mr-3' />Bio: {postt.bio}</p>
      </div>
      
      
    </div>
   </>
  )
}


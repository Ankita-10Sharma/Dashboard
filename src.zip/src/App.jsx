import { useState } from 'react'
import Profile from './Components/Profile';
import Login from './Components/Login';
import { Route, Routes } from 'react-router-dom';
import Slidebar from './Components/Slidebar';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <div className='flex'>
    <div className='w-[20%] border border-l-slate-5000'>
      <Slidebar/>
    </div>
    <div>
    <Routes>
    <Route exact path="/" element={<Login/>} />
    <Route path= "/profile/:uid" Component={Profile} />
    </Routes>
    </div>
    </div>
    </>
  )
}

export default App
